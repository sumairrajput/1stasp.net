﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Configuration;
using System.Data.SqlClient;

public partial class UserPanel : System.Web.UI.MasterPage
{
    string str = ConfigurationManager.ConnectionStrings["db"].ConnectionString;
    string str1;
    SqlCommand com;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["USERNAME"] != null)
        {
            //   Label1.Text = "" + Session["USERNAME"].ToString() + "";
            //    //Label2.Text = "Email," + Session["EMAIL"].ToString() + "";
            SqlConnection con = new SqlConnection(str);
            con.Open();
            str1 = "select * from Registration where Email='" + Session["USERNAME"].ToString() + "'";
            com = new SqlCommand(str1, con);
            SqlDataAdapter da = new SqlDataAdapter(com);
            DataSet ds = new DataSet();
            da.Fill(ds);
            lbluname.Text = ds.Tables[0].Rows[0]["Username"].ToString();
            // Label3.Text = ds.Tables[0].Rows[0]["Password"].ToString();
            //Label4.Text = ds.Tables[0].Rows[0]["Retypepassword"].ToString();
            //   Label5.Text = ds.Tables[0].Rows[0]["Userrole"].ToString();
            // Label1.Text = ds.Rows[0]["Email"].ToString();
            //    if (ds.Tables[0].Rows[0]["Image"].ToString().Length > 1)
            //    { 
            //        Image1.ImageUrl = ds.Tables[0].Rows[0]["Image"].ToString();
            //    }
            //}
            str1 = "select Image from Registration where Email='" + Session["USERNAME"].ToString() + "'";
            com = new SqlCommand(str1, con);
            SqlDataReader rdr = com.ExecuteReader();
            if (rdr.HasRows)
            {
                while (rdr.Read())
                {
                    byte[] imgdata = (byte[])rdr["Image"];
                    string img = Convert.ToBase64String(imgdata, 0, imgdata.Length);
                    Image1.ImageUrl = "data:/Image/jpg;base64," + img;
                    //Image1.ImageUrl = ds.Tables[0].Rows[0]["Image"].ToString();

                }
            }
            //if (ds.Tables[0].Rows[0]["Image"].ToString().Length > 1)
            //{ 
            //    //Image1.ImageUrl = ds.Tables[0].Rows[0]["Image"].ToString();
            //}
        }
        else
        {
            //  Response.Redirect("Login.aspx");
        }
        //string str = ConfigurationManager.ConnectionStrings["db"].ConnectionString;
        //using (SqlConnection cnn = new SqlConnection(str))
        //{
        //    SqlCommand cmm = new SqlCommand("select * from Registration", cnn);
        //    SqlDataAdapter sda = new SqlDataAdapter(cmm);
        //    DataTable dt = new DataTable();
        //    sda.Fill(dt);
        //    Label2.Text = dt.Rows[2]["Username"].ToString();
        //    //Label3.Text = dt.Rows[2]["Role"].ToString();



        //}
        //if (Request.Cookies["USERNAME"] == null)
        //{
        //    //Response.Redirect("Login.aspx");
        //}
        //else
        //{
        //    try
        //    {

        //        string st = ConfigurationManager.ConnectionStrings["db"].ConnectionString;
        //        using (SqlConnection cnn = new SqlConnection(st))
        //        {
        //            SqlDataAdapter sa = new SqlDataAdapter("select * from Registration where Email='" + Request.Cookies["USERNAME"]["Email"].ToString() + "'", cnn);
        //            DataTable dt = new DataTable();
        //            sa.Fill(dt);
        //            Label2.Text = dt.Rows[0]["Username"].ToString();
        //            Label3.Text = dt.Rows[1]["Email"].ToString();
        //        }
        //    }
        //    catch (Exception ex)
        //    {

        //        Response.Write(ex.Message);


        //    }

    
}
}
