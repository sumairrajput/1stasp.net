﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

public partial class Recoverpassword : System.Web.UI.Page
{
    string st = ConfigurationManager.ConnectionStrings["db"].ConnectionString;
    string GUIDvalue;
    DataTable dt = new DataTable();
    int Uid;
    protected void Page_Load(object sender, EventArgs e)
    {
        this.UnobtrusiveValidationMode = System.Web.UI.UnobtrusiveValidationMode.None;

        using (SqlConnection cnn = new SqlConnection(st))
        {

            GUIDvalue = Request.QueryString["Uid"];
            if(GUIDvalue !=null)
            {
                SqlCommand cmm1 = new SqlCommand("select * from ForgotPassRequests where id='" + GUIDvalue + "'", cnn);
                cnn.Open();
                SqlDataAdapter sda = new SqlDataAdapter(cmm1);
                sda.Fill(dt);
                if(dt.Rows.Count!=0)
                { 
                Uid = Convert.ToInt32(dt.Rows[0][1]);
                }
                else
                {
                    Label1.Text = "Your password reset link is expired or invalid.";
                    tbNewpassword.Visible = false;
                    tbConfirmpassword.Visible = false;
                    Btnrecoverpassword.Visible = false;
                }
            }
            else
            {
                Response.Redirect("Home.aspx");
            }
        }
        if(!IsPostBack)
        {
            if(dt.Rows.Count!=0)
            {

            }
            else
            {
                Label1.Text = "Your password reset link is expired or invalid.";
            }
        }

    }

    protected void Button1_Click(object sender, EventArgs e)
    {

    }

    protected void Btnrecoverpassword_Click(object sender, EventArgs e)
    {
        using (SqlConnection cnn = new SqlConnection(st))
        {
            SqlCommand cmm1 = new SqlCommand("update Registration set Password='" + tbNewpassword.Text + "' where Uid='"+Uid+"'", cnn);
            cnn.Open();
            cmm1.ExecuteNonQuery();
            SqlCommand cmm2 = new SqlCommand("delete ForgotPassRequests  where Uid='" + Uid + "'", cnn);
            cmm2.ExecuteNonQuery();
            Response.Redirect("Sign up.aspx");
        }
    }
}