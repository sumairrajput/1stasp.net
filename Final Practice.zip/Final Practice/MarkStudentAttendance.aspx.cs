﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.IO;
using System.ComponentModel;
using System.Drawing;
using System.Text;
using System.Threading.Tasks;

public partial class MarkStudentAttendance : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            //this.txtDate.Text = DateTime.Now.ToShortDateString();
            this.PopulateStudentDetails();
        }

    }
    private void PopulateStudentDetails()
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["db"].ConnectionString);
        SqlDataAdapter da = new SqlDataAdapter("SELECT Uid ,Username FROM Registration", con);
        DataSet ds = new DataSet();
        da.Fill(ds);
        reploaduserprof.DataSource = ds.Tables[0];
        reploaduserprof.DataBind();
    }

    protected void Savebtn_Click(object sender, EventArgs e)
    {
        //{
        //    foreach (TableRow row in reploaduserprof.rows)
        //    {
        //        if (row.RowType == DataControlRowType.DataRow)
        //        {
        //            RadioButton Prb = row.FindControl("Prb") as RadioButton;
        //            RadioButton Arb = row.FindControl("Arb") as RadioButton;
        //            RadioButton Lrb = row.FindControl("Lrb") as RadioButton;
        //            string attendanceStatus = Prb.Checked ? "Present" : Arb.Checked ? "Absent" : Lrb.Checked ? "Leave":;
        //            string attendanceStatus1 = Arb.Checked ? "Absent" ;
        //            string attendanceStatus2 = Lrb.Checked ? "Leave" ;
        //            string companyid = ((row.FindControl("lblCompanyID") as Label).Text.Trim());
        //            string employeename = ((row.FindControl("lblUsername") as Label).Text.Trim());
        //            //string sttendenceDate = (this.txtDate.Text.Trim());
        //            string constring = "Data Source=RAJPUT\\SQLEXPRESS;Initial Catalog=CeilingCentre;Integrated Security=True";
        //            using (SqlConnection con = new SqlConnection(constring))
        //            {
        //                string query = "INSERT INTO AdminAttandance VALUES(@Company_ID ,@Employee_Name,@Attendance_Status,@Attendance_Date)";
        //                using (SqlCommand cmd = new SqlCommand(query, con))
        //                {
        //                    con.Open();
        //                    cmd.Parameters.AddWithValue("@Company_ID", companyid);
        //                    cmd.Parameters.AddWithValue("@Employee_Name", employeename);
        //                    cmd.Parameters.AddWithValue("@Attendance_Status", attendanceStatus);
        //                    //cmd.Parameters.AddWithValue("@Attendance_Date", this.txtDate.Text.Trim());
        //                    cmd.ExecuteNonQuery();
        //                    //Label3.Text = "Successed";
        //                    con.Close();
        //                }
        //            }
        //        }
        //    }

        //}
    }


    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }

    protected void reploaduserprof_ItemCommand(object source, RepeaterCommandEventArgs e)
    {

    }
}