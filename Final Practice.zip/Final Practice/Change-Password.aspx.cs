﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;

public partial class Change_Password : System.Web.UI.Page
{
    string str = ConfigurationManager.ConnectionStrings["db"].ConnectionString;
    string str1 = null;
    SqlCommand com;
    byte up;
    protected void Page_Load(object sender, EventArgs e)
    {
        this.UnobtrusiveValidationMode = System.Web.UI.UnobtrusiveValidationMode.None;

    }

    protected void Btnrecoverpassword_Click(object sender, EventArgs e)
    {
        string st = ConfigurationManager.ConnectionStrings["db"].ConnectionString;
        using (SqlConnection cnn = new SqlConnection(st))
        {


            SqlDataAdapter sda = new SqlDataAdapter("Select Password from Registration where Password='" + tbCurrentpassword.Text + "'", cnn);
            //SqlDataAdapter sda = new SqlDataAdapter("Select * from Registration ", cnn);
            DataTable dt = new DataTable();
            sda.Fill(dt);

            if (dt.Rows.Count.ToString() == "1")
            {

                if (tbPassword.Text == tbRepeatepassword.Text)
                {
                    cnn.Open();
                    SqlCommand cmm = new SqlCommand("update Registration set  Password='" + tbPassword.Text + "' where Email='" + Session["USERNAME"].ToString() + "'", cnn);
                    cmm.ExecuteNonQuery();
                    cnn.Close();
                    //Label1.Text = "Password successfully changed.";
                    Response.Redirect("Login.aspx");


                }
                else
                {
                    Label1.Text = "Password and new password should be same.";
                }
            }


            else
            {
                Label1.Text = "Please check your old password.";

            }
        }



    //    SqlConnection con = new SqlConnection(str);
    //    con.Open();
    //    str1 = "select * from Registration ";
    //    com = new SqlCommand(str1, con);
    //    SqlDataReader rdr = com.ExecuteReader();
    //    while (rdr.Read())
    //    {
    //        if (tbRepeatepassword.Text == rdr["Password"].ToString())
    //        {
    //            up = 1;
    //        }
    //    }
    //   con.Close();
    //    if (up == 1)
    //    {
    //        con.Open();
    //        str1 = "update Registration set Password=@Password where Username='" + Session["USERNAME"].ToString() + "'";
    //        com = new SqlCommand(str1, con);
    //        com.Parameters.Add(new SqlParameter("@Password", SqlDbType.VarChar, 50));
    //        com.Parameters["@Password"].Value = tbPassword.Text;
    //        com.ExecuteNonQuery();
    //        con.Close();
    //        Label1.Text = "Password changed Successfully";
    //    }
    //    else
    //    {
    //        Label1.Text = "Please enter correct Current password";
    //    }
    }


  
}
