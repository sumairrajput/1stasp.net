﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Drawing;
using System.Net;
using System.Net.Mail;
public enum MessageType { Success, Error, Info, Warning };
public partial class Forgot_Password : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        this.UnobtrusiveValidationMode = System.Web.UI.UnobtrusiveValidationMode.None;
    }

    protected void TextBox1_TextChanged(object sender, EventArgs e)
    {

    }

    //protected void Button1_Click(object sender, EventArgs e)
    //{
    //    string str = ConfigurationManager.ConnectionStrings["db"].ConnectionString;
    //    using (SqlConnection cnn = new SqlConnection(str))
    //    {
    //        SqlCommand cmm = new SqlCommand("select * from Registration where  Email='" + tbEmail.Text + "' ", cnn);
    //        cnn.Open();
    //        SqlDataAdapter sda = new SqlDataAdapter(cmm);
    //        DataTable dt = new DataTable();
    //        sda.Fill(dt);
    //        if (dt.Rows.Count != 0)
    //        {
    //            String myguid = Guid.NewGuid().ToString();
    //            int UId = Convert.ToInt32(dt.Rows[0][0]);
    //            SqlCommand cmm1 = new SqlCommand("insert into Forgotpassword values ('" + myguid + "','" + UId + "',getdate())", cnn);
    //            cmm1.ExecuteNonQuery();

    //            string toemailaddress = dt.Rows[0][3].ToString();
    //            string Username = dt.Rows[0][0].ToString();
    //            String emailbody = "Hi " + Username + ",<br/><br/>Click the link below to reset your password<br/><br/>http://localhost:65322/Recoverpassword.aspx?UId=" + myguid;
    //            MailMessage mm = new MailMessage("sumairrajput465@gmail.com", toemailaddress);
    //            mm.Body = emailbody;
    //            mm.IsBodyHtml = true;
    //            mm.Subject = "Reset  password";
    //            SmtpClient smtp = new SmtpClient("smtp.gmail.com", 587);
    //            smtp.Credentials = new NetworkCredential("sumairrajput465@gmail.com", "sumair786,.");
    //            //{
    //            //    Username = "yourusername@gmaii.com";
    //            //    //Password = "yourGmailPassword";
    //            //};
    //            smtp.EnableSsl = true;
    //            smtp.Send(mm);

    //            Label2.Text = "Check your email to reset your password";
    //        }
    //        else
    //        {
    //            Label2.Text = "Your email address dosn't exists.";

    //        }


    //    }
    //}
    protected void ShowMessage(string Message, MessageType type)
    {
        ScriptManager.RegisterStartupScript(this, this.GetType(), System.Guid.NewGuid().ToString(), "ShowMessage('" + Message + "','" + type + "');", true);
    }
    protected void Btnrecoverpassword_Click(object sender, EventArgs e)
    {
        string str = ConfigurationManager.ConnectionStrings["db"].ConnectionString;
        using (SqlConnection cnn = new SqlConnection(str))
        {
            SqlCommand cmm = new SqlCommand("select * from Registration where  Email='" + tbEmail.Text + "' ", cnn);
            cnn.Open();
            SqlDataAdapter sda = new SqlDataAdapter(cmm);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            if (dt.Rows.Count != 0)
            {
                String myGUID = Guid.NewGuid().ToString();
                int Uid = Convert.ToInt32(dt.Rows[0][0]);
                SqlCommand cmm1 = new SqlCommand("insert into ForgotPassRequests values ('" + myGUID + "','" + Uid + "',getdate())", cnn);
                cmm1.ExecuteNonQuery();
                // Send Mail
                string ToEmailAddress = dt.Rows[0][2].ToString();
                string Username = dt.Rows[0][1].ToString();
                String EmailBody = "Hi " + Username + ",<br/><br/>Click the link below to reset your password<br/><br/>http://localhost:65322/Recoverpassword.aspx?Uid=" + myGUID;

                MailMessage PassRecMail = new MailMessage("sumairrajput465@gmail.com", ToEmailAddress);
                PassRecMail.Body = EmailBody;
                PassRecMail.IsBodyHtml = true;
                PassRecMail.Subject = "Reset your password";
                SmtpClient SMTP = new SmtpClient("smtp.gmail.com", 587);
                SMTP.Credentials = new NetworkCredential()
                {
                    UserName = "sumairrajput465@gmail.com",
                    Password = "sumair786,."
                };
                SMTP.EnableSsl = true;
                SMTP.Send(PassRecMail);
                Label2.Text = "Check your email to reset your password";
                ShowMessage("Record submitted successfully", MessageType.Success);

            }
            else
            {
                    Label2.Text = "Your email address dosn't exists.";
                }
          
        }
    }

    protected void btnSuccess_Click(object sender, EventArgs e)
    {
    }
}