﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;


public partial class AdminDefault : System.Web.UI.Page
{
    string str = ConfigurationManager.ConnectionStrings["db"].ConnectionString;
    string str1;
    SqlCommand com;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["USERNAME"] != null)
        {
            Label2.Text = "" + Session["USERNAME"].ToString() + "";
            //    //Label2.Text = "Email," + Session["EMAIL"].ToString() + "";
            SqlConnection con = new SqlConnection(str);
            con.Open();
            str1 = "select * from Registration where Email='" + Session["USERNAME"].ToString() + "'";
            com = new SqlCommand(str1, con);
            SqlDataAdapter da = new SqlDataAdapter(com);
            DataSet ds = new DataSet();
            da.Fill(ds);
            Label3.Text = ds.Tables[0].Rows[0]["Password"].ToString();


        }



    }

   
}