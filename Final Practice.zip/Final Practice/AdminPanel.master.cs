﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

public partial class AdminPanel : System.Web.UI.MasterPage
{
    string str = ConfigurationManager.ConnectionStrings["db"].ConnectionString;
    string str1;
    SqlCommand com;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["USERNAME"] != null)
        {
            SqlConnection con = new SqlConnection(str);
            con.Open();
            str1 = "select * from Registration where Email='" + Session["USERNAME"].ToString() + "'";
            com = new SqlCommand(str1, con);
            SqlDataAdapter da = new SqlDataAdapter(com);
            DataSet ds = new DataSet();
            da.Fill(ds);
            lbluname.Text = ds.Tables[0].Rows[0]["Username"].ToString();
            str1 = "select Image from Registration where Email='" + Session["USERNAME"].ToString() + "'";
            com = new SqlCommand(str1, con);
            SqlDataReader rdr = com.ExecuteReader();
            if (rdr.HasRows)
            {
                while (rdr.Read())
                {
                    byte[] imgdata = (byte[])rdr["Image"];
                    string img = Convert.ToBase64String(imgdata, 0, imgdata.Length);
                     Image1.ImageUrl = "data:/Image/jpg;base64," + img;
         
                }
            }
         }
        else
        {
         }
        
    }
    
    protected void Button1_Click(object sender, EventArgs e)
    {
        Session["EMAIL"] = null;
        //Session.Clear();
        Response.Redirect("Login.aspx");
    }
}
