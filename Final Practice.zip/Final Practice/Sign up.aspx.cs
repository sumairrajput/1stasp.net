﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
using System.IO;
using System.Net.Mail;
using System.Net;
public partial class Sign_up : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        this.UnobtrusiveValidationMode = System.Web.UI.UnobtrusiveValidationMode.None;
        tbUsername.Focus();
    }

    protected void BtnSignup_Click(object sender, EventArgs e)
    {
        try
        {

            
          
                //SqlDataReader rdr;
                string filePath = imageBrowes.PostedFile.FileName;
                string filename = Path.GetFileName(filePath);
                string ext = Path.GetExtension(filename);
                string contenttype = String.Empty;
            

            //Label4.Visible = false;

            //Set the contenttype based on File Extension
            //switch (ext)
            //{
            //    case ".doc":
            //        contenttype = "application/vnd.ms-word";
            //        break;
            //    case ".docx":
            //        contenttype = "application/vnd.ms-word";
            //        break;
            //    case ".xls":
            //        contenttype = "application/vnd.ms-excel";
            //        break;
            //    case ".xlsx":
            //        contenttype = "application/vnd.ms-excel";
            //        break;
            //    case ".jpg":
            //        contenttype = "image/jpg";
            //        break;
            //    case ".png":
            //        contenttype = "image/png";
            //        break;
            //    case ".gif":
            //        contenttype = "image/gif";
            //        break;
            //    case ".pdf":
            //        contenttype = "application/pdf";
            //        break;
            //}
                //if (checkemail() == true) {
                //Label3.Text = "aaaa";
                //}
                //else
                //{
                if (ext.ToLower() == ".jpg" || ext.ToLower() == ".png" || ext.ToLower() == ".bmp" || ext.ToLower() == ".gif")
                {
                    Stream fs = imageBrowes.PostedFile.InputStream;
                    BinaryReader br = new BinaryReader(fs);
                    Byte[] bytes = br.ReadBytes((Int32)fs.Length);

                    string st = ConfigurationManager.ConnectionStrings["db"].ConnectionString;
                    using (SqlConnection cnn = new SqlConnection(st))
                    {
                        SqlCommand cmm = new SqlCommand("insert into Registration  values ('" + tbUsername.Text + "','" + tbEmail.Text + "','" + tbPassword.Text + "','" + tbMobileno.Text + "','User',@image)", cnn);

                        cnn.Open();

                        cmm.Parameters.Add("@image", SqlDbType.Binary).Value = bytes;

                        cmm.ExecuteNonQuery();
                        cnn.Close();
                        Response.Redirect("Login.aspx");
                    }
                }


            //}


            else
            {
                Label4.Visible = true;
                //Label4.Text = "| Only jpg,png,bmp and gif accepted";
            }






        }
        catch (Exception ex)
        {

            Response.Write(ex.Message);


        }
    }
    [System.Web.Services.WebMethod]

    public static string CheckEmail(string useroremail)
    {
        string retval = "";
        string str = ConfigurationManager.ConnectionStrings["db"].ConnectionString;

        SqlConnection con = new SqlConnection(str);
        con.Open();
        SqlCommand cmd = new SqlCommand("select Email from Registration where Email=@UserName", con);
         cmd.Parameters.AddWithValue("@UserName", useroremail);

        SqlDataReader dr = cmd.ExecuteReader();
        if (dr.HasRows)
        {

            retval = "true";





        }
        else
        {
            retval = "false";

        }

        return retval;
    }

    //private Boolean checkemail()
    //{
    //    Boolean emailavailable = false;
    //    string st = ConfigurationManager.ConnectionStrings["db"].ConnectionString;
    //    String myquery = "Select * from Registration where Email='" + tbEmail.Text + "'";
    //    SqlConnection con = new SqlConnection(st);
    //    SqlCommand cmd = new SqlCommand();
    //    cmd.CommandText = myquery;
    //    cmd.Connection = con;
    //    SqlDataAdapter da = new SqlDataAdapter();
    //    da.SelectCommand = cmd;
    //    DataSet ds = new DataSet();
    //    da.Fill(ds);
    //    if (ds.Tables[0].Rows.Count > 0)
    //        {
    //            emailavailable = true;

    //        }
    //        con.Close();

    //        return emailavailable;

    //}


}