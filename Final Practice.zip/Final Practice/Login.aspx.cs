﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

public partial class Login : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        this.UnobtrusiveValidationMode = System.Web.UI.UnobtrusiveValidationMode.None;
        if (!IsPostBack)
        {
            if (Request.Cookies["UNAME"] != null && Request.Cookies["PWD"] != null)
            {
                tbEmail.Text = Request.Cookies["UNAME"].Value;
                tbPassword.Attributes["value"] = Request.Cookies["PWD"].Value;
                CheckBox1.Checked = true;

            }
        }

    }

    //protected void BtnSignup_Click(object sender, EventArgs e)
    //{

    //    try
    //    {

    //        string st = ConfigurationManager.ConnectionStrings["db"].ConnectionString;
    //        using (SqlConnection cnn = new SqlConnection(st))
    //        {
    //            SqlCommand cmm = new SqlCommand("insert into Registration  values ('" + tbUsername.Text + "','" + tbEmail.Text + "','" + tbPassword.Text + "','" + tbConfirmpassword.Text + "','Admin')", cnn);
    //            cnn.Open();
    //            cmm.ExecuteNonQuery();
    //            Response.Redirect("Login.aspx");
    //        }
    //    }
    //    catch (Exception ex)
    //    {

    //        Response.Write(ex.Message);


    //    }
    //}

    protected void BtnSignin_Click(object sender, EventArgs e)
    {
        try
        {
            string str = ConfigurationManager.ConnectionStrings["db"].ConnectionString;
            using (SqlConnection cnn = new SqlConnection(str))
            {
                SqlCommand cmm = new SqlCommand("select * from Registration where  Email='" + tbEmail.Text + "' and Password='" + tbPassword.Text + "'", cnn);
                SqlDataAdapter sda = new SqlDataAdapter(cmm);
                DataTable dt = new DataTable();
                sda.Fill(dt);
                if (dt.Rows.Count != 0)
                {
                    if (CheckBox1.Checked)
                    {
                        Response.Cookies["UNAME"].Value = tbEmail.Text;
                        Response.Cookies["PWD"].Value = tbPassword.Text;

                        Response.Cookies["UNAME"].Expires = DateTime.Now.AddDays(15);
                        Response.Cookies["PWD"].Expires = DateTime.Now.AddDays(15);
                    }
                    else
                    {

                        Response.Cookies["UNAME"].Expires = DateTime.Now.AddDays(-1);
                        Response.Cookies["PWD"].Expires = DateTime.Now.AddDays(-1);
                    }
                    string Urole;
                    Urole = dt.Rows[0][5].ToString().Trim();
                    if(Urole=="Admin")
                    {
                        Session["USERNAME"] = tbEmail.Text;
                        Response.Redirect("AdminDefault.aspx");
                    }
                    if (Urole == "User")
                    {
                        Session["USERNAME"] = tbEmail.Text;
                        Response.Redirect("UserDefault.aspx");
                    }
                }
                else
                {
                    //Label4.Text = "Invalid email or password";
                }

            }


        }
        catch (Exception ex)
        {

            Response.Write(ex.Message);


        }
  //      < system.webServer >
  //executionTimeout = "1600" requestLengthDiskThreshold = "2147483647"
  //  < security >
  
  //    < requestFiltering >
  
  //      < requestLimits maxAllowedContentLength = "2147483647" />
   
  //     </ requestFiltering >
   
  //   </ security >
  // </ system.webServer >
    }
}
        
