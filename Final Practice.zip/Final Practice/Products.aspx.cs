﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Products : System.Web.UI.Page

{
    string str = ConfigurationManager.ConnectionStrings["db"].ConnectionString;
    string str1;
    SqlCommand com;
    protected void Page_Load(object sender, EventArgs e)
    {
        //if (!IsPostBack)
        //{
        //    String CS = ConfigurationManager.ConnectionStrings["db"].ConnectionString;
        //    using (SqlConnection con = new SqlConnection(CS))
        //    {
        //        using (SqlCommand cmd = new SqlCommand("select * from tblProductImages", con))
        //        {
        //            //cmd.CommandType = CommandType.StoredProcedure;
        //            {
        //                con.Open();
        //                SqlDataReader rdr = cmd.ExecuteReader();

        //                if (rdr.HasRows)
        //                {
        //                    while (rdr.Read())
        //                    {
        //                        byte[] imgdata = (byte[])rdr["Image"];
        //                        string img = Convert.ToBase64String(imgdata, 0, imgdata.Length);
        //                        img = "data:/Image/jpg;base64," + img;
        //                    }
        //                }
        //            }
        //                        {
        //                using (SqlDataAdapter sda = new SqlDataAdapter(cmd))
        //                {

        //                    DataTable dtBrands = new DataTable();
        //                    sda.Fill(dtBrands);
        //                    ListView1.DataSource = dtBrands;
        //                    ListView1.DataBind();
        //                }
        //            }

        //        }
        //    }
        //    //BindProductRepeater();
        //}

        if (!IsPostBack)
        {
            BindProductRepeater();
        }
    }
          
    private void BindProductRepeater()
    {
        String CS = ConfigurationManager.ConnectionStrings["db"].ConnectionString;
        using (SqlConnection con = new SqlConnection(CS))
        {
            using (SqlCommand cmd = new SqlCommand("select * from tblProductImages", con))
            {
                using (SqlDataAdapter sda = new SqlDataAdapter(cmd))
                {
                    DataTable dtBrands = new DataTable();
                    sda.Fill(dtBrands);
                    //img.ImageUrl = dtBrands.Rows[0]["Image"].ToString();
                    rptrProducts.DataSource = dtBrands;
                    rptrProducts.DataBind();
                }

            }
        }
    }
}
