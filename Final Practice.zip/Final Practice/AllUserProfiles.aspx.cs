﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

public partial class AllUserProfiles : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        this.UnobtrusiveValidationMode = System.Web.UI.UnobtrusiveValidationMode.None;

        if (!IsPostBack)
        {
            reptloaduserfrof();
        }

    }
    private void reptloaduserfrof()
    {
        string st = ConfigurationManager.ConnectionStrings["db"].ConnectionString;
        using (SqlConnection cnn = new SqlConnection(st))
        {
            using (SqlCommand cmm = new SqlCommand("select *  from Registration  ", cnn))
            {
                using (SqlDataAdapter sda = new SqlDataAdapter(cmm))
                {
                    DataTable dt = new DataTable();
                    sda.Fill(dt);
                    reploaduserprof.DataSource = dt;
                    reploaduserprof.DataBind();
                }
            }
        }
    }


    protected void Button2_Click(object sender, EventArgs e)
    {
        if (DropDownList1.Text == "Uid")
        {
            string st = ConfigurationManager.ConnectionStrings["db"].ConnectionString;
            using (SqlConnection cnn = new SqlConnection(st))
            {
                using (SqlCommand cmm = new SqlCommand("select * from [Registration] where Uid like '" + TextBox1.Text + "%'", cnn))
                {
                    SqlDataAdapter adp = new SqlDataAdapter();
                    adp.SelectCommand = cmm;
                    DataSet ds = new DataSet();
                    adp.Fill(ds);
                    reploaduserprof.DataSource = ds;
                    reploaduserprof.DataBind();
                    cnn.Close();
                }
            }
        }
        else
        {
            string st = ConfigurationManager.ConnectionStrings["db"].ConnectionString;
            using (SqlConnection cnn = new SqlConnection(st))
            {
                using (SqlCommand cmm = new SqlCommand("select * from [Registration] where Username like '" + TextBox1.Text + "%'", cnn))
                {
                    SqlDataAdapter adp = new SqlDataAdapter();
                    adp.SelectCommand = cmm;
                    DataSet ds = new DataSet();
                    adp.Fill(ds);
                    reploaduserprof.DataSource = ds;
                    reploaduserprof.DataBind();
                    cnn.Close();
                }
            }
        }
      

    }



}